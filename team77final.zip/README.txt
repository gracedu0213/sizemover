Dashboard URL: https://public.tableau.com/profile/alvin1663#!/vizhome/CSE6424Team77SizeMovers-VisualizingIndustryClassification/ClusterExplorer?publish=yes

Demo URL: https://youtu.be/NhxzPyTDGJs

-------------------------------------------------------------------------------
----------------------------- Monthly Return Data -----------------------------
-------------------------------------------------------------------------------
In order to retrieve the monthly return dataset, you first need to sign up for the Wharton Research Data Service (WRDS). This can be done via following link: https://wrds-www.wharton.upenn.edu/. Once approved, navigate to "Compustat - Capital IQ" and then "North America - Daily". On that page we are interested in two datasets: "Security Monthly" and "Index Constituents".
Data wrangling to be performed:
	1) Data prep on clean data for monthly security returns retrieved from WRDS under Compustat Daily Updates - Security Monthly. This can be found via the following link: https://wrds-web.wharton.upenn.edu/wrds/ds/compd/secm/index.cfm?navId=83
	   	Retrieve data with search entire database option data items include all 
	   DATA tab select columns for gvkey, tic, fic, cik, conm, GICSCODE, NAICSCODE, trt1m, markecap (CSHOM:Shares outstanding * PRCCM:closing price)
	   Mapping tab: Take DATA tab security identifier keys and sub industry code and map against GICS mapping (step 4) and NAICS mapping table retrieved from: https://www.census.gov/eos/www/naics/concordances/concordances.html
	2) Drop rows where there is no GICS Sector code or trt1m (1 Month Total Return) is null 
	3) Select 1 ticker per company to avoid double or triple counting in universe. Most securities that trade with multiple tickers will trade very closely such as GOOG and GOOGL. We note there were 767 companies identified with more than 1 ticker between 1990 and 2020 within the dataset. Our method is to select the company with the largest total market cap across time.
	4) Retrieve baseline GICS sector and industry data from MSCI website https://www.msci.com/gics and  https://www.msci.com/documents/1296102/11185224/GICS_map+2018.xlsx/0b3ec4d5-9fdf-55a4-94b0-324bf17169fe
		Real Estate – In Aug 2016 the Industry Group Real Estate was reclassified out of the Financials Sector and a newly created Real Estate sector was created
		For the purposes of this exercise we reclassify items in our mapping table to the current classifications for Real Estate as there is no substantive change between the previous mapping under the Financials Sector (see table Remapped Financials to Real Estate)
		We also note in Sept 2018 a Telecommunications was removed and a new Communication Services was formed. We have chosen NOT to adjust for this as this classification change made a number of substantive changes to the nature of Communications Services, including the combination of many companies in the IT and Consumer sectors for example Facebook and Alphabet were moved to Communication Services while Microsoft remains in the Information Technology sector. To our knowledge, no mapping to historical sectors exists or is done in practice and we believe that this is a material change which should be reflected in the baseline classification.
		The following data points were reclassified in their gsubind attribute from Financials to Real Estate: 40401010, 40401020, 40402010, 40402020, 40402030,40402035, 40402040, 40402045, 40402050, 40402060, 40402070, 40403010, 40403020, 40403030, 40403040

For cleaned data, please access https://github.com/gracedu0213/sizemover for:
NA_Ret_Data_clean_v1.xlsx (Cleaned data with stock return data only)
-------------------------------------------------------------------------------
----------------------------- Sentiment Analysis ------------------------------
-------------------------------------------------------------------------------
In order to perform the sentiment analysis, the following scripts need to be executed (in listed order). Detailed explanation can be found further down. One script requires additional manual action before running
	1) edgar_master_index_download.py
	2) edgar_master_index_clean.py
	3) download_clean_10k.py
	4) extract_mda.py
	5) master_dictionary.py (manual step of retrieving word dictionaries first)
	6) cosine_similarity.py
	7) sentiment.py
	8) financial_word_count_cik_year.py
	9) monthly_return_results_merge.py

Scripts developed, but not used
	full_word_count_cik.py
	full_word_count_cik_year.py
	full_word_count_year.py
	extract_mda_parallel.py
	financial_word_count_cik.py
	financial_word_count_year.py

Directory Structure next to base folder
	data/
	download/
	logs/
	master_dictionary/
	master_index/
	results/

Detailed steps
0) Prerequisite for the sentiment analysis is to have the filtered monthly returns in (i.e. the dataset pruned from 6.3 million entries to 0.76 million entries). In terms of infrastructure, most scripts can be run on a standard performant machine (although will take several hours to complete), but there is one script in particular we ran on a virtual machine on Azure.

1) edgar_master_index_download.py
This script retrieves the master index of all SEC filings and will store the results in a compressed file named master_index.zip in master_index/ (compressed the file size is ~300 MB versus 2.6 GB uncompressed). We retrieve all the filings as of 1999.

2) edgar_master_index_clean.py
This script takes the compressed master index and merges it with the companies listed in the monthly return data file (sheet named "Mapping"). The output only considers 10-K forms (i.e. annual reports). The corresponding path to the monthly returns mapping sheet must be set in this script (e.g. data/). The output is file named master_index_filtered.csv that contains the CIK, filing date, form type and URI to access the annual report.

3) download_clean_10k.py
This script downloads the annual reports and already filters out the binary files along with cleaning up the data structure in the raw text files. Unprocessed download size is 500 GB. We ran this particular script on multiple Azure Data Science Virtual Machines. The script already contains process parallelization to facilitate the download. The result is stored in download/ and has one folder per Central Index Key (company).

4) extract_mda.py
This script takes the semi-pre-processed download and extract the MD&A section. The results are stored in mda_extract/ for further processing. Parallelized version of the script is also available.

5) master_dictionary.py
Before running this script, the dictionaries need to be retrieved from https://sraf.nd.edu/textual-analysis/resources/ - we need both the 2018 Master Dictionary in csv format and the Generic Stop Words file in txt format. This script will extract positive, negative, litigious and stop words and store the files in master_dictionary/ for subsequent steps.

6) cosine_similarity.py
This script will calculate the change of language in the MD&A sections (comparing one year to the next) and the output is stored in a JSON format containing a nested structure of data and score per Central Index Key. The equivalent is also stored in a log file in logs/, whereas in results/ you can find the JSON file.

7) sentiment.py
This script calculates the polarity for each MD&A section and stores its results in logs/ and results/ in a log and JSON file respectively.

8) financial_word_count_cik_year.py
This script computes the word count per Central Index Key per year in a JSON format for visualization.

9) monthly_return_results_merge.py
This script appends the similarity and polarity scores to the original dataset for further processing in the clustering algorithms.

For cleaned data, please access https://github.com/gracedu0213/sizemover for
NA_Ret_Data_Clean_Sentiment_v2.xlsx (Cleaned data with stock return and sentiment analysis data)

-------------------------------------------------------------------------------
--------------------------------- Clustering ----------------------------------
-------------------------------------------------------------------------------
To carry out clustering analysis, the following files must be placed in the same directory and Jupyter Notebooks must be installed with Python 3.7.x:
K Means Clustering Euclidean No-Sentiment.ipynb
K Means Clustering Euclidean Sentiment Analysis.ipynb
final_project.ipynb
NA_Ret_Data_clean_v1.xlsx
NA_Ret_Data_Clean_Sentiment_v2.xlsx

Detail Steps
1) To run clustering analysis on stock return data for Euclidean distance K-means clustering, open up "K Means Clustering Euclidean No-Sentiment.ipynb" through Jupyter Notebooks and execute the code segment by segment.
2) To run clustering analysis on sentiment analysis data for Euclidean distance K-means clustering, open up "K Means Clustering Euclidean Sentiment Analysis.ipynb" through Jupyter Notebooks and execute the code segment by segment.
3) To run clustering analysis on stock return and sentiment analysis data for Dynamic Timeseries Wrapping K Means clustering, open up "final_project.ipynb" through Jupyer Notebooks and execute the code segment by segment.

-------------------------------------------------------------------------------
------------------------------- Visualization ---------------------------------
-------------------------------------------------------------------------------
Access the visualization Dashboard at: https://public.tableau.com/profile/alvin1663#!/vizhome/CSE6424Team77SizeMovers-VisualizingIndustryClassification/ClusterExplorer?publish=yes
Alternative, install the latest version of Tableu and access the Tableau dashboard files named:
CSE6242 Team 77 Size Movers - Visualizing Industry Classification.twbx

Steps for navigation and usage:
1) Navigate various tabs at the top of the dashboard
2) Clusters vs bench tab allows selection of clustering methodology used through the dropdown menu compared to benchmark classifications. Can select relevant time periods for comparison as desired.
On the right, the top diagram compares the cumulative stock returns using portfolios constructed from our clustering results and portfolios constructed through benchmark classifications.
At the bottom, the chart shows a comparison of stock portfolio return volatility between the selected clustering method and benchmark classifications.
3) The All Clusters tab explores the same as the previous but with all cluster types on display simultaneously.
4) The cluster explorer tab allows users to explore cluster assignments of companies compared to traditional GICS and NAICS industry classifications
5) The remaining tabs on the top allows users to explore sentiment analysis results and further explore clustering assignment details.
6) A treemap is available by clicking on the "Click to Show Treemap" button, users can hover over grid to get a look into industry comparison. Users can click on grid to filter the table below. Select date ranges and compare clusters vs sectors.
7) Sent Wordcloud / Sent Treemap / Sent Bar: User can select clustering variations in Sentiment Method, Year Range, and Dimension to see word count visualization at each cluster level by selecting Cluster. Word count range helps to filter the words by their frequency.
